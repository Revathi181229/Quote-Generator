// Array of jokes
const jokes = [
  "Why don't scientists trust atoms? Because they make up everything!",
  "Why don't skeletons fight each other? They don't have the guts!",
  "What do you call fake spaghetti? An impasta!",
  "Why don't some couples go to the gym? Because some relationships don't work out!",
  "I told my wife she was drawing her eyebrows too high. She looked surprised!",
  "Why don't eggs tell jokes? They might crack up!",
  "What do you call a snowman with a six-pack? An abdominal snowman!",
  "Why do we never tell secrets on a farm? Because the potatoes have eyes and the corn has ears!"
];

// Function to generate a random joke
function generateJoke() {
  const randomNumber = Math.floor(Math.random() * jokes.length);
  const jokeElement = document.getElementById("joke-text");
  jokeElement.textContent = jokes[randomNumber];
}

// Attach click event to the button
const generateBtn = document.getElementById("generate-btn");
generateBtn.addEventListener("click", generateJoke);
